/*
 * After moving to TypeORM, this script no longer works.
 * If you have NOT migrated to TypeORM, please follow
 * https://github.com/syzoj/syzoj/wiki/TypeORM-%E8%BF%81%E7%A7%BB%E6%8C%87%E5%8D%97
 * 
 */
